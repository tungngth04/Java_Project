/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bookmanager;

/**
 *
 * @author admin
 */
public class BookManager {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        ReaderInterface JRI = new ReaderInterface();
        JRI.show();
    }
}
